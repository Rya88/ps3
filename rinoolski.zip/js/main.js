var plugin = new MovianPlugin('com.you.rinolski', 'Rinolski', 'video', true);
plugin.addURI('rinolski:browse', browseRinolski, { title: 'Browse Rinolski' });

function browseRinolski(page, uri) {
    page.type = 'directory';
    page.entries = 0;

    var url = 'https://rinolski.neocities.org/';
    var doc = showtime.httpGet(url).toString();

    var re = /<a href=\"(\/watch\/[^\"]+)\">([^<]+)<\/a>/g;
    var match;
    while ((match = re.exec(doc))) {
        page.appendItem('rinolski:play:' + match[1], 'video', {
            title: match[2],
            icon: plugin.path + 'resources/icon.png'
        });
    }
    page.loading = false;
}

plugin.addURI('rinolski:play:(.*)', function(page, path) {
    var url = 'https://rinolski.neocities.org/' + path;
    var doc = showtime.httpGet(url).toString();

    var videoUrlMatch = /<source src=\"([^\"]+)\" type=\"video\/mp4\"/.exec(doc);
    if (videoUrlMatch) {
        page.type = 'video';
        page.source = 'videoparams:' + showtime.JSONEncode({
            sources: [{ url: videoUrlMatch[1] }]
        });
        page.metadata.title = page.metadata.title || 'Rinolski Video';
    } else {
        page.error('Video URL not found');
    }
    page.loading = false;
});
